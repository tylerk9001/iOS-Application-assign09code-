//
//  PostViewController.swift
//  Personal App
//
//  Created by Tyler Kautz on 4/14/19.
//  Copyright © 2019 Tyler Kautz. All rights reserved.
//

import UIKit
import Firebase

class PostViewController: UIViewController {
   
    @IBOutlet weak var titleField: UITextField!
    @IBOutlet weak var dateField: UITextField!
    @IBOutlet weak var descField: UITextView!
    
    var titleText = ""
    var dateText = ""
    var descText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func done(_ sender: Any) {
        self.titleText = titleField.text!
        self.dateText = dateField.text!
        self.descText = descField.text!
        performSegue(withIdentifier: "post", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! LivesViewController
        vc.finalTitle = self.titleText
        vc.finalDate = self.dateText
        vc.finalDesc = self.descText
    }
    
    @IBAction func logoutTapped(_ sender: Any) {
        
        do {
            try Auth.auth().signOut()
            dismiss(animated: true, completion: nil)
        }
        catch {
            print("There was a problem logging out.")
        }
    }
    
    @IBAction func dismissKeyboard(_ sender: Any) {
        self.resignFirstResponder()
    }
    
}
