//
//  LivesViewController.swift
//  Personal App
//
//  Created by Tyler Kautz on 4/14/19.
//  Copyright © 2019 Tyler Kautz. All rights reserved.
//

import UIKit

class LivesViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var descLabel: UITextView!
    
    var finalTitle = ""
    var finalDate = ""
    var finalDesc = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        titleLabel.text = finalTitle
        dateLabel.text = finalDate
        descLabel.text = finalDesc
        
        // Do any additional setup after loading the view.
    }
}
