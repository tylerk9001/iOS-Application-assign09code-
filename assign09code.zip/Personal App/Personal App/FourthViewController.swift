//
//  FourthViewController.swift
//  Personal App
//
//  Created by Tyler Kautz on 3/31/19.
//  Copyright © 2019 Tyler Kautz. All rights reserved.
//

import UIKit
import MessageUI

class FourthViewController: UIViewController, MFMailComposeViewControllerDelegate {

    
    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var phoneNumberField: UITextField!
    @IBOutlet weak var messageField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func submit(_ sender: Any) {
        let toRecipients = ["tkkautz@gmail.com"]
        
        let mc:MFMailComposeViewController = MFMailComposeViewController()
        
        mc.mailComposeDelegate = self
        
        mc.setToRecipients(toRecipients)
        mc.setSubject("www.TylerKautz.com Form Submission")
        
        mc.setMessageBody("First Name: \(firstNameField.text!)\n\nLast Name: \(lastNameField.text!)\n\nEmail: \(emailField.text!)\n\nPhone Number: \(phoneNumberField.text!)\n\nComments or Questions: \(messageField.text!)", isHTML: false)
        
        self.present(mc, animated: true, completion: nil)
        
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result.rawValue {
        case MFMailComposeResult.cancelled.rawValue:
            print("Canceled")
            
        case MFMailComposeResult.failed.rawValue:
            print("Failed")
            
        case MFMailComposeResult.saved.rawValue:
            print("Saved")
            
        case MFMailComposeResult.sent.rawValue:
            print("Sent")
            
        default:
            break
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func dismissKeyboard(_ sender: Any) {
        self.resignFirstResponder()
    }
}
