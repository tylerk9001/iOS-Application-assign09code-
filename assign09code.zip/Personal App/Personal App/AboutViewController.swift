//
//  AboutViewController.swift
//  Personal App
//
//  Created by Tyler Kautz on 4/14/19.
//  Copyright © 2019 Tyler Kautz. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {
    @IBOutlet var educationButtons: [UIButton]!
    @IBOutlet var projectButtons: [UIButton]!
    @IBOutlet var involvementButtons: [UIButton]!
    @IBOutlet var experienceButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func handleSelection(_ sender: UIButton) {
        educationButtons.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    
    @IBAction func handleSelectionProjects(_ sender: UIButton) {
        projectButtons.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    
    @IBAction func handleSelectionExperience(_ sender: UIButton) {
        experienceButtons.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
    
    @IBAction func handleSelectionInvolvement(_ sender: UIButton) {
        involvementButtons.forEach { (button) in
            UIView.animate(withDuration: 0.3, animations: {
                button.isHidden = !button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }
}
